Daftar + Auto Claim Voucher Gofood Terbaru 22/02/2020


Jangan Lupa Berdoa Sebelum Menjalankan Scripnya
Perhatikan Langkah-Langkahnya

1. pkg update
2. pkg upgrade
3. pkg install php
4. pkg install curl
5. pkg install git
7. git clone https://github.com/trians215/cocol
Lalu masukan kode perintah untuk menjalankan script , Kode dibawah ini untuk daftar dan auto claim voucher gofood gojek
8. cd cocol
9. php cocol.php
10. Masukin nomor yang mau didaftarkan
11. Masukin Kode Otpnya
Enter Dan Selesai
