Daftar + Auto Claim Voucher Gofood + Buat Pin Terbaru 25/02/2020

Jangan Lupa Berdoa Sebelum Menjalankan Scripnya
Perhatikan Langkah-Langkahnya

1. pkg update
2. pkg upgrade
3. pkg install php
4. pkg install curl
5. pkg install git
7. git clone https://github.com/trians215/cocol
Lalu masukan kode perintah dibawah ini buntuk menjalankan script.
8. cd claim
9. php pin.php
10. Masukin nomor yang mau didaftarkan
11. Masukin Kode Otpnya Tunggu hingga selesai
12. setelah selesai ketik "y" untuk buat pin Dan "n" jika tidak ingin buat pin
Enter Dan Selesai
